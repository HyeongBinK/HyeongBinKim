#pragma once
#include "BaseHeader.h"
#include "Weapon.h"

class Sword : public Weapon
{
private :
protected :
public :
	string WeaponNamePlusWeaponType();
	//void PrintWeaponType();
	Sword();
	~Sword();
};

