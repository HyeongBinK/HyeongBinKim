#include"BaseHeader.h"
#include"GameManager.h"

void main()
{
	srand(time(NULL));
	GameManager Game_Manager;
	Game_Manager.PlayGame();
	//G_M.GameTest();
}