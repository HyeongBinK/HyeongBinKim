#include "Sword.h"

Sword::Sword()
{

}

string Sword::WeaponNamePlusWeaponType()
{
	return "�Ѽհ� ";
}

//void Sword::PrintWeaponType()
//{
//	cout << "�Ѽհ� ";
//}

Sword::~Sword()
{

}