#include "TwoHandSword.h"

TwoHandSword::TwoHandSword()
{

}

string TwoHandSword::WeaponNamePlusWeaponType()
{
	return "�μհ� ";
}

//void TwoHandSword::PrintWeaponType()
//{
//	cout << "�μհ� ";
//}

TwoHandSword::~TwoHandSword()
{

}